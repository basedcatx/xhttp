#include <libssh2.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <arpa/inet.h>
#include <unistd.h>
#include <errno.h>

#define SERVER_IP "facebook.com"   // Replace with your SSH server IP
#define SERVER_PORT 22
#define USERNAME "root"      // Replace with your SSH username
#define PASSWORD "Sudoking12@based"      // Replace with your SSH password
#define LOCAL_PROXY_PORT 8080         // Local port for HTTP proxy

void handle_http_request(int client_socket) {
    char buffer[4096];
    ssize_t nbytes;

    // Read the HTTP request from the client (simple GET request)
    nbytes = recv(client_socket, buffer, sizeof(buffer), 0);
    if (nbytes <= 0) {
        fprintf(stderr, "Failed to read from client.\n");
        close(client_socket);
        return;
    }

    // Print out the request (just for debugging)
    printf("Received request:\n%s\n", buffer);

    // Example: extract the URL from the GET request (naive approach)
    if (strncmp(buffer, "GET ", 4) != 0) {
        fprintf(stderr, "Only GET requests are supported.\n");
        close(client_socket);
        return;
    }

    // Find the URL after the GET request (naive approach)
    char *url_start = buffer + 4;
    char *url_end = strchr(url_start, ' ');
    if (!url_end) {
        fprintf(stderr, "Malformed GET request.\n");
        close(client_socket);
        return;
    }
    *url_end = '\0';  // Null-terminate the URL string

    // Send a response back (for now, we'll just send a simple static response)
    const char *http_response = "HTTP/1.1 200 OK\r\nContent-Type: text/plain\r\n\r\nHello from HTTP Proxy!";
    send(client_socket, http_response, strlen(http_response), 0);

    // Close the client connection
    close(client_socket);
}

int main() {
    int sock;
    struct sockaddr_in server_addr;
    LIBSSH2_SESSION *session;
    LIBSSH2_LISTENER *listener;
    LIBSSH2_CHANNEL *channel;
    int client_socket;
    struct sockaddr_in client_addr;
    socklen_t client_addr_len = sizeof(client_addr);

    // Initialize libssh2
    if (libssh2_init(0) != 0) {
        fprintf(stderr, "Failed to initialize libssh2.\n");
        return 1;
    }

    // Connect to SSH server
    sock = socket(AF_INET, SOCK_STREAM, 0);
    server_addr.sin_family = AF_INET;
    server_addr.sin_port = htons(SERVER_PORT);
    inet_pton(AF_INET, SERVER_IP, &server_addr.sin_addr);

    if (connect(sock, (struct sockaddr *)&server_addr, sizeof(server_addr)) != 0) {
        perror("Connect failed");
        return 1;
    }

    // Start session
    session = libssh2_session_init();
    if (!session) {
        fprintf(stderr, "Failed to initialize SSH session.\n");
        return 1;
    }

    if (libssh2_session_handshake(session, sock) != 0) {
        fprintf(stderr, "SSH handshake failed.\n");
        return 1;
    }

    // Authenticate
    if (libssh2_userauth_password(session, USERNAME, PASSWORD) != 0) {
        fprintf(stderr, "Authentication failed.\n");
        return 1;
    }

    printf("SSH Connection Established.\n");

    // Start a simple HTTP proxy listening on localhost:8080
    listener = libssh2_channel_forward_listen_ex(session, "127.0.0.1", LOCAL_PROXY_PORT, NULL, 10);
    if (!listener) {
        fprintf(stderr, "Failed to set up listener on localhost:%d.\n", LOCAL_PROXY_PORT);
        libssh2_session_disconnect(session, "Goodbye");
        libssh2_session_free(session);
        close(sock);
        libssh2_exit();
        return 1;
    }

    printf("HTTP Proxy running on localhost:%d\n", LOCAL_PROXY_PORT);

    // Wait for incoming connections (client -> proxy)
    while (1) {
        client_socket = accept(listener->socket, (struct sockaddr *)&client_addr, &client_addr_len);
        if (client_socket < 0) {
            perror("Failed to accept client connection.");
            break;
        }

        printf("Client connected.\n");

        // Handle the incoming HTTP request
        handle_http_request(client_socket);
    }

    // Cleanup
    libssh2_channel_forward_cancel(listener);
    libssh2_session_disconnect(session, "Goodbye");
    libssh2_session_free(session);
    close(sock);
    libssh2_exit();

    return 0;
}
