#include <libssh2.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <arpa/inet.h>
#include <unistd.h>
#include <errno.h>

#define SERVER_IP "facebook.com"  // Replace with your SSH server IP
#define SERVER_PORT 22
#define USERNAME "root"    // Replace with your SSH username
#define PASSWORD "Sudoking12@based"    // Replace with your SSH password
#define LOCAL_PROXY_PORT 9001       // Local port for SOCKS5 proxy

void handle_socks5_connection(LIBSSH2_SESSION *session, LIBSSH2_CHANNEL *channel) {
    char buffer[4096];
    ssize_t nbytes;

    // Handle the SOCKS5 handshake (version 5)
    nbytes = libssh2_channel_read(channel, buffer, sizeof(buffer));
    if (nbytes <= 0) {
        fprintf(stderr, "Failed to read from SOCKS5 channel.\n");
        return;
    }

    // Check if we received the SOCKS5 handshake request
    if (nbytes < 3 || buffer[0] != 0x05) {
        fprintf(stderr, "Invalid SOCKS5 handshake request.\n");
        return;
    }

    // The client is requesting authentication methods
    unsigned char response[] = { 0x05, 0x00 }; // No authentication
    libssh2_channel_write(channel, response, sizeof(response));

    // Read the CONNECT request from the client (usually [SOCKS5, CONNECT, RESERVED, ATYP, DST_ADDR, DST_PORT])
    nbytes = libssh2_channel_read(channel, buffer, sizeof(buffer));
    if (nbytes <= 0) {
        fprintf(stderr, "Failed to read from SOCKS5 client.\n");
        return;
    }

    if (buffer[0] != 0x05 || buffer[1] != 0x01 || buffer[2] != 0x00) {
        fprintf(stderr, "Invalid SOCKS5 request.\n");
        return;
    }

    // Extract the destination address and port from the request
    char *dst_address = &buffer[4];   // This is where the destination address starts
    unsigned short dst_port = (buffer[nbytes - 2] << 8) + buffer[nbytes - 1]; // Last 2 bytes are the port

    printf("Forwarding request to %s:%d\n", dst_address, dst_port);

    // Now, create the SSH channel to the destination and forward the data
    int forward_sock = socket(AF_INET, SOCK_STREAM, 0);
    if (forward_sock < 0) {
        perror("Failed to create forward socket");
        return;
    }

    struct sockaddr_in dest_addr;
    dest_addr.sin_family = AF_INET;
    dest_addr.sin_port = htons(dst_port);
    if (inet_pton(AF_INET, dst_address, &dest_addr.sin_addr) <= 0) {
        perror("Invalid destination address");
        close(forward_sock);
        return;
    }

    if (connect(forward_sock, (struct sockaddr*)&dest_addr, sizeof(dest_addr)) < 0) {
        perror("Failed to connect to destination");
        close(forward_sock);
        return;
    }

    // Send a successful response to the SOCKS5 client
    unsigned char success_response[] = { 0x05, 0x00, 0x00, 0x01, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00 };
    libssh2_channel_write(channel, success_response, sizeof(success_response));

    // Now forward data between the client and the destination server
    while ((nbytes = libssh2_channel_read(channel, buffer, sizeof(buffer))) > 0) {
        // Forward data from the SOCKS5 client to the destination server
        send(forward_sock, buffer, nbytes, 0);
    }

    while ((nbytes = recv(forward_sock, buffer, sizeof(buffer), 0)) > 0) {
        // Forward data from the destination server back to the SOCKS5 client
        libssh2_channel_write(channel, buffer, nbytes);
    }

    // Clean up
    close(forward_sock);
}

int main() {
    int sock;
    struct sockaddr_in server_addr;
    LIBSSH2_SESSION *session;
    LIBSSH2_LISTENER *listener;
    LIBSSH2_CHANNEL *channel;

    // Initialize libssh2
    if (libssh2_init(0) != 0) {
        fprintf(stderr, "Failed to initialize libssh2.\n");
        return 1;
    }

    // Connect to SSH server
    sock = socket(AF_INET, SOCK_STREAM, 0);
    server_addr.sin_family = AF_INET;
    server_addr.sin_port = htons(SERVER_PORT);
    inet_pton(AF_INET, SERVER_IP, &server_addr.sin_addr);

    if (connect(sock, (struct sockaddr *)&server_addr, sizeof(server_addr)) != 0) {
        perror("Connect failed");
        return 1;
    }

    // Start session
    session = libssh2_session_init();
    if (!session) {
        fprintf(stderr, "Failed to initialize SSH session.\n");
        return 1;
    }

    if (libssh2_session_handshake(session, sock) != 0) {
        fprintf(stderr, "SSH handshake failed.\n");
        return 1;
    }

    // Authenticate
    if (libssh2_userauth_password(session, USERNAME, PASSWORD) != 0) {
        fprintf(stderr, "Authentication failed.\n");
        return 1;
    }

    printf("SSH Connection Established.\n");

    // Start a SOCKS5 dynamic port forwarding
    listener = libssh2_channel_forward_listen_ex(session, "127.0.0.1", LOCAL_PROXY_PORT, NULL, 10);
    if (!listener) {
        fprintf(stderr, "Failed to set up SOCKS proxy on port %d.\n", LOCAL_PROXY_PORT);
        libssh2_session_disconnect(session, "Goodbye");
        libssh2_session_free(session);
        close(sock);
        libssh2_exit();
        return 1;
    }

    printf("SOCKS5 Proxy running on localhost:%d\n", LOCAL_PROXY_PORT);

    // Wait for an incoming connection (client -> proxy)
    while (1) {
        channel = libssh2_channel_forward_accept(listener);
        if (!channel) {
            fprintf(stderr, "Failed to accept forwarded connection.\n");
            break;
        }

        printf("Proxy connection accepted.\n");

        handle_socks5_connection(session, channel);

        // Close the channel
        libssh2_channel_close(channel);
        libssh2_channel_free(channel);
    }

    // Cleanup
    libssh2_channel_forward_cancel(listener);
    libssh2_session_disconnect(session, "Goodbye");
    libssh2_session_free(session);
    close(sock);
    libssh2_exit();

    return 0;
}
