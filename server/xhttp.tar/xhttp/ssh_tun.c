#include <libssh2.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <arpa/inet.h>
#include <unistd.h>
#include <errno.h>

#define SERVER_IP "localhost"  // Replace with your SSH server IP
#define SERVER_PORT 22
#define USERNAME "root"    // Replace with your SSH username
#define PASSWORD "Sudoking12@based"    // Replace with your SSH password
#define LOCAL_PROXY_PORT 9000       // Local port for SOCKS5 proxy

int main() {
    int sock;
    struct sockaddr_in server_addr;
    LIBSSH2_SESSION *session;
    LIBSSH2_LISTENER *listener;
    LIBSSH2_CHANNEL *channel;

    // Initialize libssh2
    if (libssh2_init(0) != 0) {
        fprintf(stderr, "Failed to initialize libssh2.\n");
        return 1;
    }

    // Connect to SSH server
    sock = socket(AF_INET, SOCK_STREAM, 0);
    server_addr.sin_family = AF_INET;
    server_addr.sin_port = htons(SERVER_PORT);
    inet_pton(AF_INET, SERVER_IP, &server_addr.sin_addr);

    if (connect(sock, (struct sockaddr *)&server_addr, sizeof(server_addr)) != 0) {
        perror("Connect failed");
        return 1;
    }

    // Start session
    session = libssh2_session_init();
    if (!session) {
        fprintf(stderr, "Failed to initialize SSH session.\n");
        return 1;
    }

    if (libssh2_session_handshake(session, sock) != 0) {
        fprintf(stderr, "SSH handshake failed.\n");
        return 1;
    }

    // Authenticate
    if (libssh2_userauth_password(session, USERNAME, PASSWORD) != 0) {
        fprintf(stderr, "Authentication failed.\n");
        return 1;
    }

    printf("SSH Connection Established.\n");

    // Start a SOCKS5 dynamic port forwarding
    listener = libssh2_channel_forward_listen_ex(session, "127.0.0.1", LOCAL_PROXY_PORT, NULL, 10);
    if (!listener) {
        fprintf(stderr, "Failed to set up SOCKS proxy on port %d.\n", LOCAL_PROXY_PORT);
        libssh2_session_disconnect(session, "Goodbye");
        libssh2_session_free(session);
        close(sock);
        libssh2_exit();
        return 1;
    }

    printf("SOCKS5 Proxy running on localhost:%d\n", LOCAL_PROXY_PORT);

    // Wait for an incoming connection (client -> proxy)
    while (1) {
        channel = libssh2_channel_forward_accept(listener);
        if (!channel) {
            fprintf(stderr, "Failed to accept forwarded connection.\n");
            break;
        }

        printf("Proxy connection accepted.\n");

        // You can handle the channel data here (e.g., HTTP request)
        char buffer[4096];
        ssize_t nbytes = libssh2_channel_read(channel, buffer, sizeof(buffer));
        if (nbytes > 0) {
            fwrite(buffer, 1, nbytes, stdout);
        }

        // Close the channel
        libssh2_channel_close(channel);
        libssh2_channel_free(channel);
    }

    // Cleanup
    libssh2_channel_forward_cancel(listener);
    libssh2_session_disconnect(session, "Goodbye");
    libssh2_session_free(session);
    close(sock);
    libssh2_exit();

    return 0;
}
