#include <libssh2.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <arpa/inet.h>
#include <unistd.h>

#define SSH_SERVER "localhost"   // SSH server IP/hostname
#define SSH_PORT 22                   // SSH port (default is 22)
#define USERNAME "root"      // SSH username
#define PASSWORD "Sudoking12@based"      // SSH password
#define REMOTE_HOST "facebook.com"     // Remote HTTP server
#define REMOTE_PORT 80                // HTTP server port
#define BUFFER_SIZE 2048

int main() {
    LIBSSH2_SESSION *session;
    LIBSSH2_CHANNEL *channel;
    int sock;
    struct sockaddr_in server_addr;

    // Initialize libssh2
    if (libssh2_init(0) != 0) {
        fprintf(stderr, "libssh2 initialization failed\n");
        return 1;
    }

    // Create a socket and connect to the SSH server
    sock = socket(AF_INET, SOCK_STREAM, 0);
    if (sock < 0) {
        perror("Socket creation failed");
        return 1;
    }

    server_addr.sin_family = AF_INET;
    server_addr.sin_port = htons(SSH_PORT);
    inet_pton(AF_INET, SSH_SERVER, &server_addr.sin_addr);

    if (connect(sock, (struct sockaddr *)&server_addr, sizeof(server_addr)) < 0) {
        perror("Connection to SSH server failed");
        close(sock);
        return 1;
    }

    // Start an SSH session
    session = libssh2_session_init();
    if (!session) {
        fprintf(stderr, "Failed to create SSH session\n");
        close(sock);
        return 1;
    }

    if (libssh2_session_handshake(session, sock) != 0) {
        fprintf(stderr, "SSH handshake failed\n");
        libssh2_session_free(session);
        close(sock);
        return 1;
    }

    // Authenticate with username and password
    if (libssh2_userauth_password(session, USERNAME, PASSWORD) != 0) {
        fprintf(stderr, "SSH authentication failed\n");
        libssh2_session_disconnect(session, "Failed to authenticate");
        libssh2_session_free(session);
        close(sock);
        return 1;
    }

    printf("SSH connection established.\n");

    // Open a direct TCP/IP channel to the remote HTTP server
    channel = libssh2_channel_direct_tcpip(session, REMOTE_HOST, REMOTE_PORT);
    if (!channel) {
        fprintf(stderr, "Failed to open direct TCP/IP channel\n");
        libssh2_session_disconnect(session, "Failed to open channel");
        libssh2_session_free(session);
        close(sock);
        return 1;
    }

    // Send an HTTP request
    const char *http_request = "GET /get HTTP/1.1\r\n"
                               "Host: httpbin.org\r\n"
                               "Connection: close\r\n\r\n";

    if (libssh2_channel_write(channel, http_request, strlen(http_request)) < 0) {
        fprintf(stderr, "Failed to send HTTP request\n");
        libssh2_channel_close(channel);
        libssh2_channel_free(channel);
        libssh2_session_disconnect(session, "Failed to send data");
        libssh2_session_free(session);
        close(sock);
        return 1;
    }

    printf("HTTP request sent.\n");

    // Read the HTTP response
    char buffer[BUFFER_SIZE];
    ssize_t bytes_read;

    printf("Response:\n");
    while ((bytes_read = libssh2_channel_read(channel, buffer, sizeof(buffer) - 1)) > 0) {
        buffer[bytes_read] = '\0';  // Null-terminate the buffer
        printf("%s", buffer);
    }

    if (bytes_read < 0) {
        fprintf(stderr, "Error reading HTTP response\n");
    }

    // Clean up
    libssh2_channel_close(channel);
    libssh2_channel_free(channel);
    libssh2_session_disconnect(session, "Normal Shutdown");
    libssh2_session_free(session);
    close(sock);
    libssh2_exit();

    printf("\nConnection closed.\n");
    return 0;
}
